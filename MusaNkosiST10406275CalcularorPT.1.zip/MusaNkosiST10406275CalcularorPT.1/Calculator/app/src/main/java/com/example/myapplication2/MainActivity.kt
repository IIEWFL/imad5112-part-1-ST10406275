package com.example.myapplication2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {
    private var number1: TextView? = null
    private var number2: TextView? = null
    private var answer: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)
        answer = findViewById(R.id.tvAnswer)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSub = findViewById<Button>(R.id.btnSub)
        val btnMul = findViewById<Button>(R.id.btnMul)
        val btnDiv = findViewById<Button>(R.id.btnDiv)
        val btnSqr = findViewById<Button>(R.id.btnSqr)
        val btnPow = findViewById<Button>(R.id.btnPow)
        val btnStat = findViewById<Button>(R.id.btnStat)

        btnAdd.setOnClickListener {
            add()
        }

        btnSub.setOnClickListener {
            subtract()
        }

        btnMul.setOnClickListener {
            multiply()
        }

        btnDiv.setOnClickListener {
            divide()
        }

        btnSqr.setOnClickListener {
            squareRoot()
        }

        btnPow.setOnClickListener {
            power()
        }

        btnStat.setOnClickListener {
            statistics()
        }


    }

    private fun add() {

        if (isNotEmpty()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            answer?.text = input1.add(input2).toString()
        }
    }

    private fun isNotEmpty(): Boolean {

        var b = true
        if (number1?.text.toString().trim().isEmpty()) {

            number1?.error = "Required"
            b = false
        }

        if (number2?.text.toString().trim().isEmpty()) {

            number2?.error = "Required"
            b = false




        }
        return b
    }

    private fun subtract() {

        if (isNotEmpty()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            answer?.text = input1.subtract(input2).toString()
        }
    }

    private fun multiply() {

        if (isNotEmpty()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()
            answer?.text = input1.multiply(input2).toString()
        }
    }

    private fun divide() {
        if (isNotEmpty()) {
            val input1 = number1?.text.toString().trim().toBigDecimal()
            val input2 = number2?.text.toString().trim().toBigDecimal()


            if (input2 != BigDecimal.ZERO) {
                answer?.text = input1 . divide(input2).toString()

            } else {
                answer?.text=("Division by zero is not allowed.")
            }
        }
    }

}





    private fun squareRoot() {

    }

    private fun power() {

    }

    private fun statistics() {

    }







